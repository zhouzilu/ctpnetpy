import os
from . import predict
name = "ctpnet"
__all__=['predict']
