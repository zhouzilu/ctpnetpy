# ctpnetpy: The Python package of cTP-net

This package is designed to be used by the R code of [cTP-net](https://github.com/zhouzilu/cTPnet).

One can also use this Python package for predicting surface protein abundance from scRNA-seq data. Instructions on training will come out soon.

## Installation:

```
pip install cTPnet
```
The package only supports Python (>=3.5)
