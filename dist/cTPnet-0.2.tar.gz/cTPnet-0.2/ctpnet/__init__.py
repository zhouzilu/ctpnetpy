name = "ctpnet"
import os
__all__=['predict']
